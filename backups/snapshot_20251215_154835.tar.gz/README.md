## Simple Online Chkobba

Multiplayer Chkobba built with React + Socket.IO. Players only need a username and a 6-character room code to jump into a match, and the backend keeps the full deck, capture logic, scoring, and real-time updates in sync.

### Tech Stack
- **Frontend:** React (Vite) + socket.io-client with hover capture previews, discard confirmations, team overlays, and the bundled SVG card assets (`client/public/cards`).
- **Backend:** Node.js + socket.io with an Express dev server and a Vercel-compatible serverless handler (`server/api/socket.js`).
- **Game logic:** custom room/deck/score engine covering Kartâ, Dīnārī, Barmīla, Sabʿa l-ḥayya, Chkobba bonuses, custom targets, and 1v1 or 2v2 team scoring.

### Repository Layout
```
Chkobba/
├── client/            # React UI (lobby + gameplay)
├── server/            # Game engine, socket handlers, dev server, serverless API function
│   └── api/socket.js  # Entry point for Vercel Serverless Functions
├── README.md
└── ...
```

---

## Local Development

### 1. Backend
```bash
cd server
npm install
npm run dev   # starts http://localhost:4000 with Socket.IO
```

### 2. Frontend
```bash
cd client
npm install
cp .env.example .env             # optional, edit if needed
npm run dev                      # starts http://localhost:5173
```

`client/.env` supports:
```
VITE_SERVER_URL=http://localhost:4000   # socket.io server
VITE_SOCKET_PATH=/socket.io             # use /api/socket when hitting Vercel
```

> ℹ️ Vite 7 requires Node.js ≥ 20.19 for production builds. Dev mode works on Node 18 but upgrade Node when possible for parity with CI.

---

## Gameplay Flow
1. User enters a username, picks a room mode (1v1 vs 2v2) + target score, and either creates a room (generates a 6-char code) or joins an existing code—no auth required.
2. The host can keep adjusting the mode/target while in the lobby; settings lock only during an active round.
3. Deck (40 cards) is shuffled on the server. Four cards go to the table, then each player receives 3 cards. Every card renders with the provided SVG artwork, including the Chkobba bonus medal.
4. On a turn a player hovers a hand card to preview highlighted captures. If a card would not capture anything the UI asks for confirmation before discarding it. Server-side logic enforces:
   - Capture identical-value cards.
   - Otherwise capture the best available sum combination (2+ cards) whose value equals the played card.
   - Clearing the table grants a Chkobba bonus (rendered via `Chkobba_point.svg`).
5. After each three-card hand is exhausted, a new hand is dealt until the deck is empty. Players can inspect every card they have captured beside their hand.
6. Round scoring awards Kartâ, Dīnārī, Barmīla, Sabʿa l-ḥayya, and each Chkobba. In **1v1**, points accrue per player; in **2v2**, teammates share a single total (Team A vs Team B). First side to reach the configured target wins; otherwise, a new round starts automatically with a rotated dealer/tireur.

The UI surfaces lobby management (kick/promote, seat availability), table highlights, captured strips, team indicators, turn pills, round summaries, and toast-style errors from the server.

---

## Socket Contract

### Client → Server
| Event | Payload | Notes |
|-------|---------|-------|
| `create_room` | `{ username }` | Generates a unique room + host seat. |
| `join_room`   | `{ roomCode, username }` | Joins an existing waiting room. |
| `start_game`  | `{ roomCode }` | Host-only; deals cards & begins play. |
| `play_card`   | `{ roomCode, cardId }` | Plays a card; server resolves captures. |
| `update_settings` | `{ roomCode, targetScore?, mode? }` | Host-only; change target points or 1v1/2v2 mode from the lobby. |
| `kick_player` | `{ roomCode, playerId }` | Host removes a player (the client receives a `kicked` event and resets). |
| `transfer_host` | `{ roomCode, playerId }` | Host promotes another player to host. |
| `leave_room` | none | Player exits the room without closing the socket connection. |
| `ready_next_round` | `{ roomCode }` | Sent by each player after reviewing the round summary; the next round only begins once everyone confirms. |

### Server → Client
| Event | Payload | Notes |
|-------|---------|-------|
| `room_created` | `{ roomCode }` | Confirmation for hosts. |
| `joined_room`  | `{ roomCode }` | Confirmation for guests. |
| `room_update`  | lobby summary | Player list, dealer/tireur badges, mode, seats remaining, etc. |
| `game_update`  | per-player state | Includes your hand, table cards, captured pile, team layout/scores, round summary, action log. |
| `action_error` | `{ message }` | User feedback for invalid actions. |
| `kicked` | none | Sent to a client when the host removes them. |

---

## Deploying to Vercel

You can keep the backend and frontend as two separate Vercel projects:

1. **Backend project**
   - Root directory: `server`
   - Build command: `npm install`
   - Output directory: *(leave blank)* – Vercel will deploy `server/api/socket.js` as a Serverless Function.
   - Environment: Node 20+
   - Enable the WebSocket feature flag in your Vercel project settings (beta feature as of writing).

2. **Frontend project**
   - Root directory: `client`
   - Build command: `npm install && npm run build`
   - Output directory: `dist`
   - Environment variables:
     - `VITE_SERVER_URL=https://<your-backend>.vercel.app`
     - `VITE_SOCKET_PATH=/api/socket`

Once deployed, the React app will connect to the serverless socket endpoint automatically using those env vars.

---

## Verification

- `client`: `npm run build` (ensures the bundle renders cleanly – expect a Node-version warning on 18.x but the build still succeeds)
- `server`: manual verification via `npm run dev` + connecting the React UI. The server layer is pure Node/Socket.IO with no build step.

---

## Next Steps / Ideas
1. Persist room state in an external store (Redis) for long-running rooms across server restarts.
2. Add card selection on the client to let players choose which combination to capture when multiple options exist.
3. Animate card movements + add sound cues for captures/Chkobba moments.
4. Expose a history log per round and allow spectators to join as read-only participants.
#   C h k o b b a  
 